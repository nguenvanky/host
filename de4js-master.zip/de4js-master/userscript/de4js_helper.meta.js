// ==UserScript==
// @version      1.1.0
// @name         de4js helper
// @namespace    https://baivong.github.io/de4js/
// ==/UserScript==